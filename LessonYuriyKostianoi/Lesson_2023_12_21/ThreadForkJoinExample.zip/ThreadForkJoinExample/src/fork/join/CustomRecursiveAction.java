package fork.join;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveAction;
import java.util.logging.Logger;

/**
 * Ниже пример создания рекурсивной задачи, не возвращающей результата.
 * Строка workload представляет единицу обрабатываемой информации.
 * Выполняемая задача - это перевод полученной строки в верхний регистр и логирование.
 * Для демонстрации разделения на подзадачи задано условие, что при длине workload больше значения THRESHOLD будет
 * использована параллельная обработка. Разбиение на подзадачи выполнено в методе createSubtask().
 * Строка рекурсивно делится на подстроки, на основании которых создаются объекты подзадач CustomRecursiveTask.
 * Результатом является список List<CustomRecursiveAction>.
 * Этот список передаётся в ForkJoinPool с помощью метода invokeAll().
 */

public class CustomRecursiveAction extends RecursiveAction {
    private String workload = "";
    private static final int THRESHOLD = 4;

    private static final Logger logger = Logger.getAnonymousLogger();

    public CustomRecursiveAction(String workload) {
        this.workload = workload;
    }

    @Override
    protected void compute() {
        if (workload.length() > THRESHOLD) {
            ForkJoinTask.invokeAll(createSubtasks());
        } else {
            processing(workload);
        }
    }

    private List<CustomRecursiveAction> createSubtasks() {
        List<CustomRecursiveAction> subtasks = new ArrayList<>();

        String partOne = workload.substring(0, workload.length() / 2);
        String partTwo = workload.substring(workload.length() / 2);

        subtasks.add(new CustomRecursiveAction(partOne));
        subtasks.add(new CustomRecursiveAction(partTwo));

        return subtasks;
    }

    private void processing(String work) {
        String result = work.toUpperCase();
        logger.info("This result - (" + result + ") - was processed by " + Thread.currentThread().getName());
    }
}
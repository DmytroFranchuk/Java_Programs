import fork.join.CustomRecursiveAction;
import fork.join.CustomRecursiveTask;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
        CustomRecursiveAction action = new CustomRecursiveAction("abcdef".repeat(100));
        action.fork();
        System.out.println("Результат выполнения join у action:" + action.join());

        CustomRecursiveTask task = new CustomRecursiveTask(
                ThreadLocalRandom.current().ints().limit(100).toArray()
        );
        ForkJoinPool pool = ForkJoinPool.commonPool();
        pool.execute(task);
        int result = task.join();
        System.out.println("Результат выполнения join у task:" + result);
        result = pool.invoke(task);
        System.out.println("Результат выполнения invoke у task:" + result);
    }
}
package person;

import java.util.concurrent.ThreadLocalRandom;

public class Developer extends Employee {

    public Developer(String name, String company) {
        super(name, company);
    }

    @Override
    public void work() {
        System.out.println("I wrote this code: " + generateCode());
    }

    private String generateCode() {
        return "if() ".repeat(ThreadLocalRandom.current().nextInt(100));
    }
}

package person;

import java.util.List;

public class Manager extends Employee {
    private final List<Employee> employees;

    public Manager(String name, String company, List<Employee> employees) {
        super(name, company);
        this.employees = employees;
    }


    @Override
    public void display() {
        super.display();
        System.out.println("My employees: " + employees);
    }

    @Override
    public void work() {
        for (Employee employee: employees) {
            System.out.printf("Hey, %s, work!%n", employee.getName());
        }
    }
}

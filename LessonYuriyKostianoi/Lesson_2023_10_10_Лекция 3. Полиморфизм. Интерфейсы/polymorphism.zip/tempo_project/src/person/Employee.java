package person;

public abstract class Employee extends Person {
    private final String company;

    public Employee(String name, String company) {
        super(name);
        this.company = company;
    }

    public String getCompany() {
        return company;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Company: " + company);
    }

    public abstract void work();
}

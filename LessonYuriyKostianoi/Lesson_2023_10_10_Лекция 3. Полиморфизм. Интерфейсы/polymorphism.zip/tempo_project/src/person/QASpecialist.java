package person;

import java.util.ArrayList;
import java.util.List;

public class QASpecialist extends Employee {

    private final List<String> bugs;

    public QASpecialist(String name, String company) {
        super(name, company);
        bugs = new ArrayList<>();
    }

    @Override
    public void work() {
        bugs.add("a new bug");
        System.out.println("You need to fix all of this: " + bugs);
    }
}

import person.*;

import java.util.List;

public class Organization {
    public static void main(String[] args) {
        Person person = new Person("Peter");
        // Employee person = new Employee("Nikol", "Youtube"); // ошибка компиляции: нельзя создать экземпляр абстрактного класса
        Developer backendDeveloper = new Developer("Nikol", "Youtube");
        Employee someEmployee = new Developer("Jimmy", "Youtube"); // Полиморфизм! Наследник помещается в предка
        Developer frontendDeveloper = (Developer) someEmployee; // Если в переменной типа предка хранится наследник, то переменную можно явно преобразовать к классу-наследнику
        // Если someEmployee не является Developer, то будет выброшено ClassCastException, поэтому для проверки используют instanceof
        frontendDeveloper = someEmployee instanceof Developer ? (Developer) someEmployee : null;
        frontendDeveloper.work(); // у класса Employee этот метод является абстрактным, но ошибки не будет
        Person somebody = frontendDeveloper; // Полиморфизм! Наследник помещается в предка
        // somebody.work(); // ошибка компиляции: у класса Person нет метода work()
        QASpecialist qa = new QASpecialist("Valery", "Youtube");
        Manager manager = new Manager(
                "Sam",
                "Youtube",
                List.of(backendDeveloper, someEmployee, qa) // Employee всех типов можно поместить в один список
        );

        // Поместим всех сотрудников в один список
        List<Employee> team = List.of(backendDeveloper, frontendDeveloper, qa, manager);

        // Вызов метода work для каждого сотрудника из списка
        System.out.println("\nTeam work:");
        for (Employee employee: team) {
            employee.work();
        }
    }
}
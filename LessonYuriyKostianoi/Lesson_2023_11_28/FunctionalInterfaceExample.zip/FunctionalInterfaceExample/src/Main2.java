import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.*;

public class Main2 {
    public static void main(String[] args) {
        Consumer<String> print = s -> System.out.println(s);
        Function<Integer, Integer> square = x -> x*x;
        Predicate<String> isNullOrBlank = s -> s == null || s.isBlank();
        BiConsumer<Integer, String> printAsPhrase = (age, name) -> System.out.printf("%s is %d years old", name, age);
        BiFunction<Integer, Integer, Integer> add = (a, b) -> a + b;
        BiPredicate<String, String> isFirstLonger = (s1, s2) -> s1 != null && s2 != null && s1.length() > s2.length();

        List<String> l = new ArrayList<>(List.of("", " ", "\t", "not blank", "notBlank"));
        l.removeIf(isNullOrBlank);
        System.out.println(l);
    }
}
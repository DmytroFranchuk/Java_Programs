@FunctionalInterface
public interface WorkerInterface {
    public void doSomeWork();
}

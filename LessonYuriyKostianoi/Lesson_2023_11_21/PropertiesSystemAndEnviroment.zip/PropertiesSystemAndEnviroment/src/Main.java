import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;

public class Main {
    public static void main(String[] args) {
        System.out.println("args: " + Arrays.toString(args));
        boolean isIncognito = args.length > 0 && Boolean.parseBoolean(args[0]);
        if (isIncognito) {
            System.out.println("Программа запущена в режиме инкогнито");
        }

        Map<String, String> envMap = System.getenv();
        System.out.println("\nПеременные окружения:");
        envMap.forEach((k, v) -> System.out.printf("\t%s=%s\n", k, v));

        Properties props = System.getProperties();
        System.out.println("\nНастройки окружения:");
        props.forEach((k, v) -> System.out.printf("\t%s=%s\n", k, v));

        Properties appProps = getApplicationProperties();
        System.out.println("\nНастройки приложения из файла:");
        appProps.forEach((k, v) -> System.out.printf("\t%s=%s\n", k, v));

    }

    public static Properties getApplicationProperties() {
        Properties appProperties = new Properties();
        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("resources/application.properties")) {
            appProperties.load(in);
            return appProperties;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;

public class Main {
    public static void main(String[] args) throws IOException {

        // download
        URL url1 = new URL("https://www.google.com"); // Создает объект URL с путем к странице
        InputStream input = url1.openStream(); // Получает InputStream у интернет-объекта
        byte[] buffer = input.readAllBytes(); // Читает все байты и возвращает массив байт
        String str = new String(buffer); // Преобразуем массив в строку
        System.out.println(str); // Выводим строку на экран
        input.close();

        // upload
        URL url2 = new URL("https://www.google.com"); // Создаем объект URL с путем к странице
        URLConnection connection = url2.openConnection();

        // получили поток для отправки данных
        // FIXME этот код вызовет ошибку, т.к. гугл ничего от нас не ждёт :)
        /*OutputStream output = connection.getOutputStream(); // Получаем поток вывода
        output.write(1); // отправляем данные */

        // получили поток для чтения данных
        InputStream input2 = connection.getInputStream();
        int data = input2.read(); // читаем данные

        String image = "https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png";
        downloadAndSave(image);
    }

    private static void downloadAndSave(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        InputStream input = url.openStream();

        Path path = Path.of("GoogleLogo.png");
        Files.copy(input, path);
    }
}
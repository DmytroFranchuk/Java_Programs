import iterator.StringWithIter;

import java.util.*;

public class MyIteratorExample {
    public static void main(String[] args) {
        // Example 1. Итератор по строке
        StringWithIter phrase = new StringWithIter("The input string"); // класс позволяет итерироваться по строке

        for (char z : phrase) {
            System.out.print(z + " ");
        }
        System.out.println("\n");

        // Example 2. Итератор берёт строки в порядке увеличения длины
        List<String> names = List.of("Jim", "John", "Freddy", "Ringo", "Paul");

        Iterator<String> iterator = new Iterator<>() { // анонимный класс - создаём итератор на месте.
            private final List<String> innerList = new ArrayList<>(names); // копируем исходную коллекцию

            {
                innerList.sort(Comparator.comparing(String::length)); // сортируем коллекцию по длине строк
            }

            @Override
            public boolean hasNext() {
                return !innerList.isEmpty();
            }

            @Override
            public String next() {
                if (!hasNext()) throw new NoSuchElementException();
                return innerList.remove(0);
            }
        };

        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // Example 3. Итератор массива
        // Обойти массив сначала по чётным элементам, затем по нечётным
        int[] nums1 = {0, 1, 2, 3, 4, 5, 6, 7, 8};
        Iterator<Integer> arIterator1 = getSpecArrayIterator(nums1);
        arIterator1.forEachRemaining(System.out::println);
        System.out.println();
        int[] nums2 = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        Iterator<Integer> arIterator2 = getSpecArrayIterator(nums2);
        arIterator2.forEachRemaining(System.out::println);
    }

    private static boolean isEven(int num) {
        return num % 2 == 0;
    }

    private static Iterator<Integer> getSpecArrayIterator(int[] nums) {
        if (nums == null || nums.length == 0) throw new IllegalArgumentException("Empty array");
        return new Iterator<>() {
            private int i = 0;
            private boolean isByOdd = false; // идём по нечётным
            private final int lastEven = isEven(nums.length - 1) ? nums.length - 1 : nums.length - 2;
            private final int lastOdd = !isEven(nums.length - 1) ? nums.length - 1 : nums.length - 2;

            @Override
            public boolean hasNext() {
                return !isByOdd || nums.length > 1 && i <= lastOdd;
            }

            @Override
            public Integer next() {
                if (!hasNext()) throw new NoSuchElementException();
                int next = nums[i];
                if (i + 2 <= Math.max(lastEven, lastOdd)) i += 2;
                else {
                    if (isByOdd) i++;
                    else {
                        isByOdd = true;
                        i = 1;
                    }
                }
                return next;
            }
        };
    }
}
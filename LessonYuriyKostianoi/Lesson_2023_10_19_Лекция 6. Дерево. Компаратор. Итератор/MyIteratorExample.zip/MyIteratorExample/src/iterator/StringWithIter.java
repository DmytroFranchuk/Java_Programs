package iterator;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class StringWithIter implements Iterable<Character> {

    // Строка по которой итерируемся
    private final String inputString;

    // Конструктор получающий строку
    public StringWithIter(String inputString) {
        this.inputString = inputString;
    }

    // Реализовали метод Iterable для получения итератора
    // (в нашем случае это объект вложенного класса ImplIterator, имплементирующего интерфейс Iterator)
    @Override
    public Iterator<Character> iterator() {
        return new ImplIterator();
    }

    // Класс ImplIterator, имплементирующий интерфейс Iterator
    private class ImplIterator implements Iterator<Character> {

        // Это текущий элемент в итераторе и одновременно счётчик
        int current = 0;

        // Возвращает true, если есть следующий элемент (символ)
        @Override
        public boolean hasNext() {
            // простая проверка - если текущий элемент равен количеству символов в строке, то есть
            // указывает на последний символ в строке, значит следующий элемент отсутствует и вернём false
            return current < inputString.length();
        }

        // Возвращает следующий элемент в итерации (символ)
        @Override
        public Character next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return inputString.charAt(current++);
        }
    }
}

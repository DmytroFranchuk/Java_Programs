package comparator;

public class Player implements Comparable<Player>{
    private String nickname;
    private int rank;
    private int age;

    public Player(String nickname, int rank, int age) {
        this.nickname = nickname;
        this.rank = rank;
        this.age = age;
    }

    // standard getters and setters


    public String getNickname() {
        return nickname;
    }

    public int getRank() {
        return rank;
    }

    public int getAge() {
        return age;
    }

    @Override
    public int compareTo(Player o) {
        return Integer.compare(this.rank, o.rank);
    }
}

import comparator.Player;
import comparator.PlayerAgeComparator;
import comparator.PlayerNicknameComparator;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Player> players = new ArrayList<>();
        players.add(new Player("First", 100, 25));
        players.add(new Player("AndyJ", 50, 18));
        players.add(new Player("AndyK", 90, 33));
        players.add(new Player("Xo-xo-Santa", 100, 99));
        players.add(new Player("Patron", 10, 20));

        players.sort(Comparator.naturalOrder()); // сортировка в естественном порядке
        players.forEach(p -> System.out.println(p.getRank() + " " + p.getNickname()));
        System.out.println();

        players.sort(new PlayerAgeComparator()); // Сортируем по возрасту
        players.forEach(p -> System.out.println(p.getAge() + " " + p.getNickname()));
        System.out.println();

        players.sort(new PlayerNicknameComparator()); // Сортируем по никнейму
        players.forEach(p -> System.out.println(p.getNickname()));
        System.out.println();
    }
}
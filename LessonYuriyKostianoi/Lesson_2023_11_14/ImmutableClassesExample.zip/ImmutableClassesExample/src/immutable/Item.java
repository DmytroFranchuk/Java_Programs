package immutable;

import java.util.List;

public class Item {
    private final String name;
    private final double price;
    private final String description;
    private final List<String> hashTags;

    public Item(String name, double price, String description, List<String> hashTags) {
        this.name = name;
        this.price = price;
        this.description = description;
        this.hashTags = hashTags;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getHashTags() {
        return hashTags;
    }

    public Item changeName(String newName) { // любое изменение - это создание нового объекта
        return new Item(newName, this.price, this.description, this.hashTags);
    }
}

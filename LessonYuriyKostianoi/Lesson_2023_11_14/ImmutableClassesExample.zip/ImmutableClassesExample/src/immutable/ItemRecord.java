package immutable;

import java.util.List;

public record ItemRecord(String name, double price, String description, List<String> hashTags) {
    public Item changeName(String newName) {
        return new Item(newName, this.price, this.description, this.hashTags);
    }
}

import immutable.Item;
import immutable.ItemRecord;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println(new Item("Butter", 2.0, "non-gmo", List.of("#butter", "#nongmo")));
        System.out.println(new ItemRecord("Butter", 2.0, "non-gmo", List.of("#butter", "#nongmo")));
    }
}
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        System.out.println(System.currentTimeMillis()); // получить текущее время системы в миллисекундах от 1 января 1970
        System.out.println(System.nanoTime()); // получить время в наносекундах для измерения длительности

        LocalDate today = LocalDate.now();
        LocalDate tomorrow = today.plusDays(1);
        LocalDate nextYear = today.plusYears(1);
        LocalDate myBirthday = LocalDate.of(1989, 8, 14);
        System.out.println(List.of(today, tomorrow, nextYear, myBirthday));
        System.out.println();

        // С часами (0-23) и минутами(0-59)
        LocalTime fiveThirty = LocalTime.of(5, 30);
        // С часами, минутами и секундами(0-59)
        LocalTime noon = LocalTime.of(12, 0, 0);
        // С часами, минутами, секундами и наносекундами(0-999,999,999)
        LocalTime almostMidnight = LocalTime.of(23, 59, 59, 999999);
        Duration durationToMidnight = Duration.between(LocalTime.now(), almostMidnight);
        System.out.println(durationToMidnight);

        System.out.println(fiveThirty);
        System.out.println(noon);
        System.out.println(almostMidnight);
        System.out.println();


        Duration duration0 = Duration.ZERO;
        System.out.println(duration0);
        System.out.println(duration0.plusSeconds(15));
        Period myLife = Period.between(myBirthday, today);
        System.out.println(myLife.get(ChronoUnit.YEARS));
        Period durationToNextBirthday = Period.between(
                today,
                LocalDate.of(today.plusYears(1).getYear(), 8, 14)
        );
        System.out.printf("%d месяцев и %d дней%n", durationToNextBirthday.getMonths(), durationToNextBirthday.getDays());
        System.out.println();

        LocalDateTime rightNow = LocalDateTime.now();
        System.out.println(rightNow);
        LocalDateTime dateTimeOfMyBirth = LocalDateTime.of(myBirthday, almostMidnight);
        System.out.println(dateTimeOfMyBirth);
        System.out.println();

        ZonedDateTime zonedDateTime = ZonedDateTime.now();
        System.out.println(zonedDateTime);
        System.out.println(zonedDateTime.getZone());
        System.out.println();

        DateTimeFormatter formatterUs = DateTimeFormatter.ofPattern("MMMM, dd, yyyy HH:mm:ss", Locale.US);
        System.out.println(zonedDateTime.format(formatterUs));

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        System.out.println(zonedDateTime.format(formatter));
    }
}
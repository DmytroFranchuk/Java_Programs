import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {

        Random rnd = new Random(); // создаём объект типа Random, чтобы генерировать данные
        int number = rnd.nextInt(); // любое целое число из диапазона int
        int age = rnd.nextInt(120); // любое число в диапазоне от 0 до 120
        double temperature = rnd.nextDouble(36.0,42.0); // любое дробное число в диапазоне от 36 до 42

        Random rnd2 = ThreadLocalRandom.current(); // второй способ получить экземпляр Random
        boolean isOk = rnd2.nextBoolean(); // произвольное значение из набора [true, false]


        double probability = Math.random(); // произвольное дробное число в диапазоне от 0.0 до 1.0

                // Random не умеет генерировать строки. Но это умеют делать другие классы, например UUID
        String str = UUID.randomUUID().toString();

        // Выводим результат
        System.out.printf("Произвольная строка: %s. Произвольное число %d", str, number);
        System.out.println();
        System.out.printf("Произвольный возраст человека: %d. Произвольная температура тела человека %.1f", age, temperature);
        System.out.println();
        System.out.printf("Выполнено: %s", isOk);
        System.out.println();
        System.out.printf("Вероятность: %.3f", probability);
    }
}
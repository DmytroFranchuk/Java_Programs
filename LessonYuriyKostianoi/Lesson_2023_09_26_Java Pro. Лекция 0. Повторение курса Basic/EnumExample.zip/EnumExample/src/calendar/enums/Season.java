package calendar.enums;

public enum Season {
    WINTER, // 0
    SPRING, // 1
    SUMMER, // 2
    AUTUMN // 3
}

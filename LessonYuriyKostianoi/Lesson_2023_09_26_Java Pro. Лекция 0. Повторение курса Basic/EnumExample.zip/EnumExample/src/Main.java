import calendar.enums.DayOfWeek;
import calendar.enums.Season;

import java.util.Arrays;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        Season season = Season.AUTUMN;

        System.out.println(season.name());
        System.out.println(season.ordinal());
        Season s2 = Season.valueOf("AUTUMN");
        System.out.println(s2);
        Season[] seasons = Season.values();
        System.out.println(Arrays.toString(seasons));

        String w = "winter";
        Season s3 = Season.valueOf(w.toUpperCase(Locale.ROOT));
        System.out.println(s3);
    }
}
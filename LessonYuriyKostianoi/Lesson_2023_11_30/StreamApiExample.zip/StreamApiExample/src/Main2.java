import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main2 {
    public static void main(String[] args) {
// 1 Создайте список чисел и используйте Stream API, чтобы отфильтровать только четные числа.

        List<Integer> nums = List.of(2, 3, 4, 10, 12, 1, 2, 3, 4, 5, 2, 4, 4, 5, 6, 7);
        Set<Integer> evens = nums.stream().filter(e -> e%2 ==0).collect(Collectors.toSet());
        System.out.println(evens);
    }
}
package org.example.entity;

public record StatisticsItem(String clientAppName, long clientAppCount ) {
}

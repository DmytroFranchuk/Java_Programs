package org.example.pojo;

public class FirstBean {
    private String name;

    public FirstBean(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

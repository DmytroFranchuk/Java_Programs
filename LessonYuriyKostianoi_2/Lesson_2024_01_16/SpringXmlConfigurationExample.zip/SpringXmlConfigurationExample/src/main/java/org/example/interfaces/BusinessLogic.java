package org.example.interfaces;

public interface BusinessLogic {
    void doBusinessLogic();
}

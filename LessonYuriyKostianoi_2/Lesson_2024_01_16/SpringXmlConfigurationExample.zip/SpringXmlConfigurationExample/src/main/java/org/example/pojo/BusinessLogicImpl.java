package org.example.pojo;

import org.example.interfaces.BusinessLogic;

public class BusinessLogicImpl implements BusinessLogic {

    @Override
    public void doBusinessLogic() {
        System.out.println("Do very important business logic");
    }
}

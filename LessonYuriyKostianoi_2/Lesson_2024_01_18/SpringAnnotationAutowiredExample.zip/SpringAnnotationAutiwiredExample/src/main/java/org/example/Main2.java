package org.example;

import org.example.pojo.SecondComponent;
import org.example.pojo.ThirdComponent;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main2 {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        ThirdComponent tc = context.getBean("thirdComponent", ThirdComponent.class);
        System.out.println(tc);
        context.close();
    }
}

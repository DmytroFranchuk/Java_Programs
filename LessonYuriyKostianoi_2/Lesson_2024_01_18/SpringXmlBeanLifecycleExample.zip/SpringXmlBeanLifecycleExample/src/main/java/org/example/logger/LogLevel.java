package org.example.logger;

public enum LogLevel {
    DEBUG,
    INFO,
    WARNING,
    ERROR
}

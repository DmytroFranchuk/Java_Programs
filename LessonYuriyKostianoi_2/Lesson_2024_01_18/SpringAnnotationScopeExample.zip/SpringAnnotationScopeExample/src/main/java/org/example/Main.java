package org.example;

import org.example.pojo.SecondComponent;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        SecondComponent fc1 = context.getBean("secondComponent", SecondComponent.class);
        SecondComponent fc2 = context.getBean("secondComponent", SecondComponent.class);
        System.out.println("Are the same bean: " + (fc1 == fc2));
        context.close();
    }
}

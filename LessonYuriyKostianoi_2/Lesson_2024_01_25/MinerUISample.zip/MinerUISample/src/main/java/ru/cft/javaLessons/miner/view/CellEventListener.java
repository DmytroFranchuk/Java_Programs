package ru.cft.javaLessons.miner.view;

public interface CellEventListener {
    void onMouseClick(int x, int y, ButtonType buttonType);
}

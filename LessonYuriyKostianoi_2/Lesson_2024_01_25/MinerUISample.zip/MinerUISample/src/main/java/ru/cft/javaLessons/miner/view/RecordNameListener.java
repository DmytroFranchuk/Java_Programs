package ru.cft.javaLessons.miner.view;

public interface RecordNameListener {
    void onRecordNameEntered(String name);
}

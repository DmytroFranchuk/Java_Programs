package ru.cft.javaLessons.miner.common.interfaces.game;

public enum GameResult {
    WIN, LOSE, UNDEFINED
}

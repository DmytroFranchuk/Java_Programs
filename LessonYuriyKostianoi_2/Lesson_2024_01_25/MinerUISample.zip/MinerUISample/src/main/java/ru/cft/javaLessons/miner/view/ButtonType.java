package ru.cft.javaLessons.miner.view;

public enum ButtonType {
    LEFT_BUTTON,
    RIGHT_BUTTON,
    MIDDLE_BUTTON,
}

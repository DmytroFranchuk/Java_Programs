package org.example;

import org.example.comment.ClassPreamble;
import org.example.comment.Generation3ListAfter;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Class<Generation3ListAfter> clazz = Generation3ListAfter.class;
        ClassPreamble annotation = clazz.getDeclaredAnnotation(ClassPreamble.class);
        System.out.println(annotation.author());
        System.out.println(annotation.date());
        System.out.println(annotation.currentRevision());
        System.out.println(annotation.lastModified());
        System.out.println(annotation.lastModifiedBy());
        System.out.println(Arrays.toString(annotation.reviewers()));
    }
}

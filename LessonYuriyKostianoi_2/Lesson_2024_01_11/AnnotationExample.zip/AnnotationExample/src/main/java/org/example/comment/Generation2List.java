package org.example.comment;

public class Generation2List {
}

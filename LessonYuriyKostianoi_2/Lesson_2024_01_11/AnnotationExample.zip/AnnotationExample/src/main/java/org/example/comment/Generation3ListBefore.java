package org.example.comment;

public class Generation3ListBefore extends Generation2List {
    // TODO Допустим, в проекте тела всех классов начинаются с комментариев, содержащих важную информацию:
    // Author: John Doe
    // Date: 3/17/2002
    // Current revision: 6
    // Last modified: 4/12/2004
    // By: Jane Doe
    // Reviewers: Alice, Bill, Cindy

}

package org.example.components;

public class SecondBean {
    public SecondBean() {
        System.out.println("Создание бина " + this.getClass().getSimpleName());
    }
}

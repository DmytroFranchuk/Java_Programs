package org.example.components;

public class FirstBean {
    public FirstBean() {
        System.out.println("Создание бина " + this.getClass().getSimpleName());
    }
}

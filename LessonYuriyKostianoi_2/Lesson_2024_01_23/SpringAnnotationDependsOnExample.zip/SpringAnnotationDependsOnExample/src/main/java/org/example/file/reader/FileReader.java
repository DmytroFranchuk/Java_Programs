package org.example.file.reader;

import org.example.shared.File;

public class FileReader {

    public FileReader(File file) {
        file.setText("read");
    }
    
    public void readFile() {}
}

package org.example.file.writer;

import org.example.shared.File;

public class FileWriter {
    
    public FileWriter(File file){
        file.setText("write");
    }
    
    public void writeFile(){}
}

package org.example.pojo;

public record SecondBean(FirstBean first) {
}

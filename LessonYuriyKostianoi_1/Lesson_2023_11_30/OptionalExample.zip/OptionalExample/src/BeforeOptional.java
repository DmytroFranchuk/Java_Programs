import java.util.List;

public class BeforeOptional {
    public static void main(String[] args) {
        System.out.println(getGreaterThanThat(10, List.of(0, 1, 2, 3, 4, 5)));
    }

    private static Integer getGreaterThanThat(int that, List<Integer> nums) {
        Integer num = null;
        for (int i : nums) {
            if (i > that) num = i;
        }
        return num;
    }
}
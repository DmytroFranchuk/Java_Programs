import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class AfterOptional {
    public static void main(String[] args) {
        Optional<Integer> num = getGreaterThanThat(10, List.of(0, 1, 2, 3, 4, 5));
        if (num.isPresent()) { // проверка, что значение представлено (не null)
            System.out.println(num.get()); // чтобы получить значение из обёртки, вызываем get()
        }
        if (num.isEmpty()) System.out.println(num); // обратная проверка
        num.ifPresent(System.out::println); // проверка, что объект представлен в функциональном стиле.
    }

    private static Optional<Integer> getGreaterThanThat(int that, List<Integer> nums) {
        Optional<Integer> num = Optional.empty();
        for (int i : nums) {
            if (i > that) num = Optional.of(i);
        }
        return num;
    }

    private static DayOfWeek getWeekend(LocalDate date) {
        DayOfWeek dayWeek = Optional.of(date)
                .map(LocalDate::getDayOfWeek)
                .filter(DayOfWeek.SUNDAY::equals)
                .orElse(DayOfWeek.SATURDAY);
        return dayWeek;
    }

//    public static <T> Optional<T> empty() // метод создания пустой обёртки
//    public static <T> Optional<T> of(T value) // создаём обёртку, помещая в неё value. Если value == null, будет выброшено NPE (ранний отлов null-значений)
//    public static <T> Optional<T> ofNullable(T value) // создаём обёртку, помещая в неё value. Если value == null, то будет создана пустая обёртка

//    public T get(); // получение значения из обёртки
//    public T orElseGet(Supplier<? extends T> supplier); // получить значение или, если обёртка пуста, то получить его из лямбда-выражения
//    public T orElseThrow(); // получить значение или, если обёртка пуста, бросить NoSuchElementException
//    public <X extends Throwable> T orElseThrow(Supplier<? extends X> exceptionSupplier) throws X; // получить значение или, если обёртка пуста, бросить исключение, полученное из лямбда-выражения
//    public boolean isPresent(); // проверка, что обёртка не пуста
//    public boolean isEmpty(); // проверка, что обёртка пуста
//    public void ifPresent(Consumer<? super T> action); // проверка, что объект представлен в функциональном стиле.
//    //Если объект не empty, то будет выполнено лямбда-выражение с представленным значением.
//    public void ifPresentOrElse(Consumer<? super T> action, Runnable emptyAction); // то же, но в случае пустой обёртке выполняется emptyAction

//    public Optional<T> filter(Predicate<? super T> predicate) // метод для фильтрации содержимого optional по заданному предикату
//    public <U> Optional<U> map(Function<? super T, ? extends U> mapper) // метод для замены значения с поммощью переданного лямбда-выражения (обычно на основании текущего значения)
//    public <U> Optional<U> flatMap(Function<? super T, ? extends Optional<? extends U>> mapper) // метод аналогичен map, но результат переданного лямбда-выражения уже является Optional
//    public Optional<T> or(Supplier<? extends Optional<? extends T>> supplier) // взять текущее значение, но если обёртка пуста, то выполнить лямбда-выражение
//    public Stream<T> stream() // если значение представлено, то получить поток (конвейер) из одно элемента - представленного значения

}
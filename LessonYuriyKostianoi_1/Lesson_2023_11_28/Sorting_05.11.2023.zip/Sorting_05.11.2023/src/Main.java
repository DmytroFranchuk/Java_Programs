import measure.Timer;

import java.util.Arrays;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
//        compareSortsWithAnonimClasses(50_000);
        compareSortsWithLambda(50_000);
    }

    private static void selectionSort(int[] array) {
        for (int i = 0; i < array.length; i++) {
            int min = array[i];
            int minIndex = i;
            for (int j = i + 1; j < array.length; j++) {
                if (array[j] < min) {
                    min = array[j];
                    minIndex = j;
                }
            }
            int temp = array[i];
            array[i] = min;
            array[minIndex] = temp;
        }
    }

    private static void bubbleSort(int[] sortArr) {
        for (int i = 0; i < sortArr.length - 1; i++) {
            for (int j = 0; j < sortArr.length - i - 1; j++) {
                if (sortArr[j + 1] < sortArr[j]) {
                    int swap = sortArr[j];
                    sortArr[j] = sortArr[j + 1];
                    sortArr[j + 1] = swap;
                }
            }
        }
    }

    private static void countSort(int[] array) {

        int[] additional = new int[getMax(array) + 1];
        for (int value : array) {
            additional[value]++;
        }
        int k = 0;
        for (int i = 0; i < additional.length; i++) {
            for (int j = 0; j < additional[i]; j++) {
                array[k] = i;
                k++;
            }
        }
    }

    private static int getMax(int[] array) {
        int max = array[0];
        for (int j : array) {
            if (j > max) {
                max = j;
            }
        }
        return max;
    }

    /**
     * Метод для генерации массива случайнх целых чисел
     *
     * @param testLen длина тестового массива
     * @return массив, заполненный случайными целыми числами
     */
    private static int[] generateArray(int testLen) {
        int[] arr = new int[testLen];
        for (int i = 0; i < testLen; i++) {
            arr[i] = (int) Math.round(Math.random() * 10000);
        }
        return arr;
    }

    /**
     * Метод для сравнения скорости выполнения сортировок. Метод генерирует массив заданной длины и оборачивает
     * вызов сортировки (значение) в мапу в соответствии с её названием (ключ)
     *
     * @param testLen длина тестового массива
     **/
    private static void compareSortsWithAnonimClasses(int testLen) {
        int[] arr1 = generateArray(testLen);

        // применение анонимных классов позволяет создать реализацию метода
        // и сразу же создать один экземпляр класса с этой реализацией
        Runnable bubble = new Runnable() {
            @Override
            public void run() {
                bubbleSort(Arrays.copyOf(arr1, arr1.length));
            }
        };

        Runnable select = new Runnable() {
            @Override
            public void run() {
                selectionSort(Arrays.copyOf(arr1, arr1.length));
            }
        };

        Runnable count = new Runnable() {
            @Override
            public void run() {
                countSort(Arrays.copyOf(arr1, arr1.length));
            }
        };

        Map<String, Long> sortToTime = Timer.measureTasks(
                Map.of(
                        "Сортировка пузырьком", bubble,
                        "Сортировка выбором", select,
                        "Сортировка подсчётом", count
                )
        );
        sortToTime.forEach((k, v) -> System.out.printf("%s выполнена за %d мс%n", k, v));
    }

    private static void compareSortsWithLambda(int testLen) {
        int[] arr1 = generateArray(testLen);
        Map<String, Long> sortToTime = Timer.measureTasks(
                Map.of(
                        "Сортировка пузырьком", () -> bubbleSort(Arrays.copyOf(arr1, arr1.length)),
                        "Сортировка выбором", () -> selectionSort(Arrays.copyOf(arr1, arr1.length)),
                        "Сортировка подсчётом", () -> countSort(Arrays.copyOf(arr1, arr1.length))
                )
        );
        sortToTime.forEach((k, v) -> System.out.printf("%s выполнена за %d мс%n", k, v));
    }
}
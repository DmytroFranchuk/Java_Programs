package measure;

import java.util.HashMap;
import java.util.Map;

public class Timer {
    private Timer() { }

    /**
     * Метод, который замеряет время выполнения задачи
     * @param task задача, время выполнения которой нужно измерить
     */
    public static long measureTime(Runnable task) {
        long startTime = System.currentTimeMillis();
        task.run();
        return System.currentTimeMillis() - startTime;
    }

    /**
     * Метод получения времени выполнения нескольких задач
     * @param tasks мапа, хранящая названия задач в виде ключей и соответствующие им запускаемые задачи
     * @return возвращает мапу, хранящую название задачи и измеренное время её выполнения
     */
    public static Map<String, Long> measureTasks(Map<String, Runnable> tasks) {
        Map<String, Long> sortToTime = new HashMap<>(tasks.size());
        for (String key : tasks.keySet()) {
            sortToTime.put(key, Timer.measureTime(tasks.get(key)));
        }
        return sortToTime;
    }
}

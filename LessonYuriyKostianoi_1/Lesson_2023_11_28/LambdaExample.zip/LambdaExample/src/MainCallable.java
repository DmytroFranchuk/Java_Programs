import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class MainCallable {
    public static void main(String[] args) {
        String a = "Some";
        String b = " string";
        Callable<String> giveMeString = () -> a;
        Callable<String> concat = () -> a + b;
        Callable<String> putInMiddle = () -> new StringBuilder(a).insert(a.length()/2, b).toString();
        Callable<String> mixLetter = () -> {
            String max = a.length() > b.length() ? a : b;
            String min = max.equals(b) ? a : b;
            StringBuilder sb = new StringBuilder(max);
            int indexMin = min.length() -1;
            for (int i = sb.length()-1; i >= 0; i--) {
                if (i % 2 != 0) {
                    sb.insert(i+1, min.charAt(indexMin));
                    indexMin--;
                    if (indexMin < 0) break;
                }
            }
            return sb.toString();
        };

        List<String> strs = gatherStrings(List.of(giveMeString, concat, putInMiddle, mixLetter));
        System.out.println(strs);
    }

    private static String getString(Callable<String> giveMeString) {
        try {
            return giveMeString.call();
        } catch (Exception e) {
            return null;
        }
    }

    private static List<String> gatherStrings(List<Callable<String>> suppliers) {
        List<String> strings = new ArrayList<>();
        suppliers.forEach(c -> strings.add(getString(c)));
        return strings;
    }
}
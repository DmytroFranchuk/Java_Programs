import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

public class MainFamiliarLambdas {
    public static void main(String[] args) {
        int num = 1;
        String fingerName = switch (num) {
            case 1 -> "Big";
            case 2 -> "Index";
            case 3 -> "Middle";
            case 4 -> "Ring";
            case 5 -> "Little";
            default -> {
                System.out.println("Мутанты атакуют!");
                throw new NoSuchElementException("Undefined finger");
            }
        };

        List<Integer> list = List.of(0, 1, 9, 2, 8, 3, 7, 4, 7);
        list.forEach(e -> System.out.println(e)); // лямбда-выражение для вывода каждого элемента в консоль
        list.forEach(System.out::println); // аналогичная запись с помощью ссылки на метод (компактное лямбда-выражение)

        Iterator<Integer> iterator = list.iterator();
        iterator.forEachRemaining(e -> System.out.println(e));
        iterator.forEachRemaining(System.out::println);

        Map<String, Integer> nameToAge = Map.of(
                "Peter", 21,
                "Jimmy", 14,
                "Kate", 16,
                "Nina", 20
        );
        nameToAge.entrySet().forEach(pair -> System.out.printf("I'm %s, I'm %d years old.%n", pair.getKey(), pair.getValue()));
        nameToAge.forEach((k, v) -> System.out.printf("I'm %s, I'm %d years old.%n", k, v));
    }
}
import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scn = new Scanner(Path.of("Names.txt")); // указываем классу Scanner читать из файла
        String line = scn.nextLine();
        System.out.println(line);
    }
}
import java.io.*;
import java.util.List;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) throws IOException {
        new Thread("Another thread").start(); // используем потоки (нити) в программе (многопоточная программа)

        try (InputStream input = new FileInputStream("notes.txt")) { // используем поток для чтения файла (работа с файлами)
            byte[] bytes = input.readAllBytes();
        } catch (IOException e) {
            System.err.println("Ошибка чтения файла: " + e.getLocalizedMessage());
        }

        InputStream input = null;
        try { // закрытие потока в секции finally
            input = new FileInputStream("notes.txt");
            byte[] bytes = input.readAllBytes();
        } catch (IOException e) {
            System.err.println("Ошибка чтения файла: " + e.getLocalizedMessage());
        } finally {
            if (input != null) {
                input.close();
            }
        }

        List<String> startedWithJ = Stream.of("Bill", "Jim", "Jonh", "Anna", "Jane")
                .filter(s -> s.startsWith("J"))
                .toList(); // Отфильтровали коллекцию, используя Stream API (синтаксис языка)
    }
}
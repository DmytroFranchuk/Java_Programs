package exception;

import java.util.UUID;

/**
 * Класс checked-исключений, возникающих при обработке сообщений мессенджера.
 */
public class MessageException extends Exception {
    public MessageException(String message) {
        super(message);
    }
}

package exception;

import java.util.UUID;

/**
 * Класс исключений выполнения, возникающих при обработке сообщений мессенджера.
 * Каждое исключение помечается уникальным идентификатором сообщения формата UUID для лёгкой фильтрации в логах.
 */
public class MessageRuntimeException extends RuntimeException {
    public MessageRuntimeException(UUID id) {
        super(id.toString());
    }

    public MessageRuntimeException(UUID id, String message) {
        super(id.toString() + " " + message);
    }

    public MessageRuntimeException(UUID id, String message, Throwable cause) {
        super(id.toString() + " " + message, cause);
    }

    public MessageRuntimeException(UUID id, String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(id.toString() + " " + message, cause, enableSuppression, writableStackTrace);
    }
}

import exception.MessageException;
import exception.MessageRuntimeException;
import message.Message;

import java.util.Objects;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {
        validateMessage(new Message(UUID.randomUUID(), "Hello!"));
        validateMessage(new Message(UUID.randomUUID(), ""));

        UUID id;
        try {
            id = getMessageId("964cca77-5338-48e4-9ef8-41fcbcc101ae");
        } catch (MessageException e) {
            throw new RuntimeException(e);
        }
    }

    private static void validateMessage(Message message) {
        Objects.requireNonNull(message, "Сообщение не должно быть пустым"); // Выбросит NullPointerException, если message == null
        Objects.requireNonNull(message.getId(), "Идентификатор сообщения не заполнен");
        if (message.getText() == null || message.getText().isBlank()) {
            throw new MessageRuntimeException(message.getId(), "Сообщения с пустым содержимым недопустимы");
        }
    }

    private static UUID getMessageId(String strId) throws MessageException {
        if (strId == null || strId.isBlank()) throw new MessageException("Пустой идентификатор сообщения");
        return UUID.fromString(strId);
    }
}
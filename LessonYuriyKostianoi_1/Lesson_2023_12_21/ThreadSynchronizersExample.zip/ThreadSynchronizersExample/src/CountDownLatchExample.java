import java.util.concurrent.CountDownLatch;

public class CountDownLatchExample {
    private static final int THREAD_COUNT = 3;
    private static final CountDownLatch LATCH = new CountDownLatch(THREAD_COUNT);

    public static void main(String[] args) {
        for (int i = 1; i <= THREAD_COUNT; i++) {
            Thread thread = new Thread(() -> {
                System.out.println("Thread " + Thread.currentThread().getId() + " is performing a task.");
                LATCH.countDown(); // Уменьшение счетчика на 1
            });
            thread.start();
        }

        try {
            LATCH.await(); // Ожидание, пока счетчик не станет равным нулю
            System.out.println("All threads have completed their tasks.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

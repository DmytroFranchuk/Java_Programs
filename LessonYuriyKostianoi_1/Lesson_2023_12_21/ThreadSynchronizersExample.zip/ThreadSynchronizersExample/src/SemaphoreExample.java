import java.util.concurrent.Semaphore;

public class SemaphoreExample {
    private static final int THREAD_COUNT = 5;
    private static final Semaphore SEMAPHORE = new Semaphore(2); // Допуск для двух потоков

    public static void main(String[] args) {
        for (int i = 1; i <= THREAD_COUNT; i++) {
            Thread thread = new Thread(() -> {
                try {
                    SEMAPHORE.acquire(); // Запросить разрешение на доступ к ресурсу
                    System.out.println("Thread " + Thread.currentThread().getId() + " is accessing the resource.");
                    Thread.sleep(2000); // Имитация работы с ресурсом
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    SEMAPHORE.release(); // Освободить ресурс
                    System.out.println("Thread " + Thread.currentThread().getId() + " has released the resource.");
                }
            });
            thread.start();
        }
    }
}

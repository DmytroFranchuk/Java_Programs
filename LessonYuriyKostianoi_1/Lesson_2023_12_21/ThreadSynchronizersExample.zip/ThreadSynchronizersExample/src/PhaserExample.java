import java.util.concurrent.Phaser;

public class PhaserExample {
    private static final int THREAD_COUNT = 3;
    private static final int PHASES = 3;
    private static final Phaser PHASER = new Phaser(THREAD_COUNT);

    public static void main(String[] args) {
        for (int i = 0; i < THREAD_COUNT; i++) {
            Thread thread = new Thread(() -> {
                for (int phase = 0; phase < PHASES; phase++) {
                    System.out.println("Thread " + Thread.currentThread().getId() + " is starting phase " + phase);
                    PHASER.arriveAndAwaitAdvance(); // Блокировка потока до начала следующей фазы

                    // Выполнение работы для текущей фазы
                    System.out.println("Thread " + Thread.currentThread().getId() + " is performing work for phase " + phase);
                    PHASER.arriveAndAwaitAdvance(); // Блокировка потока до завершения работы в текущей фазе
                }
            });
            thread.start();
        }

        // Дополнительная фаза для синхронизации завершения всех потоков
        for (int phase = 0; phase < PHASES; phase++) {
            System.out.println("Main thread is starting additional phase " + phase);
            PHASER.arriveAndAwaitAdvance();
        }

        System.out.println("Main thread has completed all phases.");
    }
}

import java.util.concurrent.Exchanger;

public class ExchangerExample {
    private static final Exchanger<String> exchanger = new Exchanger<>();

    public static void main(String[] args) {
        Thread producer = new Thread(() -> {
            try {
                String data = "Producer's Data";
                System.out.println("Producer is producing data: " + data);
                Thread.sleep(2000); // Имитация производства данных
                exchanger.exchange(data); // Обмен данными с другим потоком
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        Thread consumer = new Thread(() -> {
            try {
                String receivedData = exchanger.exchange(null); // Получение данных от другого потока
                System.out.println("Consumer has received data: " + receivedData);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        producer.start();
        consumer.start();
    }
}

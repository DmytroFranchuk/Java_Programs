import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scn = new Scanner(Path.of("Names.txt"));
        String names = scn.nextLine();
        System.out.println(names);
    }


}
import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Integer> nums = List.of(5, 4, 3, 2, 1, 6, 7, 8, 9, 0);
        System.out.println(findLeastN(nums, 3));
        System.out.println(findLeastN(nums, 5));
    }

    /**
     * Метод для получения n минимальных элементов коллекции.
     * Реализация с приоритетной очередью выгоднее по скорости и объёму памяти,
     * чем подход с сортировкой первоначального списка.
     *
     * @param collection исходная неотсортированная коллекция
     * @param n          количество минимальных элементов, которые нужно включить в итоговый список
     * @param <T>        параметр типа элемента коллекции
     * @return список состоящий из n минимальных элементов входной коллекции
     */
    public static <T extends Comparable<T>> List<T> findLeastN(Collection<T> collection, int n) {
        if (n <= 0) throw new IllegalArgumentException("n должно быть больше 0");
        if (collection == null || collection.isEmpty()) throw new IllegalArgumentException("Передана пустая коллекция");

        // создадим очередь с обратной сортировкой
        PriorityQueue<T> priorityQueue = new PriorityQueue<>(Collections.reverseOrder());
        for (T t : collection) { // для каждого элемента переданной коллекции
            if (priorityQueue.size() < n) {//если размер очереди < n
                priorityQueue.add(t);//добавим элемент t в очередь
            } else if (priorityQueue.peek().compareTo(t) > 0) {
                /*иначе, если первый, а значит максимальный, элемент очереди(его вернёт peek) больше t*/
                priorityQueue.poll(); //удалим первый элемент очереди
                priorityQueue.add(t);//добавим вместо него t
            }
        }
        /*создадим список из полученной очереди и отсортируем его
        в естественном порядке (задан по умолчанию в методе sort)*/
        List<T> list = new ArrayList<>(priorityQueue);
        Collections.sort(list);
        return list;
    }
}
public class WrapperExample {
    public static void main(String[] args) {
        Wrapper strWrapper = new Wrapper("Some string");
        Wrapper intWrapper = new Wrapper(999);

        String str1 = (String) strWrapper.getValue(); // Код отработает корректно
        Integer num1 = (Integer) intWrapper.getValue(); // Код отработает корректно
        System.out.println(str1);
        System.out.println(num1);

        String str2 = (String) intWrapper.getValue(); // Компилятор не ругается, но при выполнении буде ClassCastException
        Integer num2 = (Integer) strWrapper.getValue(); // Компилятор не ругается, но при выполнении буде ClassCastException
        System.out.println(str2);
        System.out.println(num2);
    }

    // Чтобы не получать ClassCastException нужно писать проверки с instanceof и явно приводить тип каждый раз
    public static String getStrValue(Wrapper wrapper) {
        return wrapper.getValue() instanceof String ? (String) wrapper.getValue() : null;
    }

    // Для каждого случая потребуется отдельный метод приведения
    public static Integer getIntValue(Wrapper wrapper) {
        return wrapper.getValue() instanceof Integer ? (Integer) wrapper.getValue() : null;
    }

    public static class Wrapper {
        private final Object value;

        public Wrapper(Object value) {
            this.value = value;
        }

        public Object getValue() {
            return value;
        }
    }
}
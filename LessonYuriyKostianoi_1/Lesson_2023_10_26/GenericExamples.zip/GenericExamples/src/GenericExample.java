public class GenericExample {
    public static void main(String[] args) {
        GenericWrapper<String> strWrapper = new GenericWrapper<>("Some string");
        GenericWrapper<Integer> intWrapper = new GenericWrapper<>(999);

        String str1 = strWrapper.getValue(); // нет необходимости явно приводить код
        Integer num1 = intWrapper.getValue(); // нет необходимости явно приводить код
        System.out.println(str1);
        System.out.println(num1);

        String str2 = intWrapper.getValue(); // Компилятор ругается на несовпадение типов
        Integer num2 = strWrapper.getValue(); // Компилятор ругается на несовпадение типов
        System.out.println(str2);
        System.out.println(num2);
    }

    public static class GenericWrapper<T> {
        private final T value;

        public GenericWrapper(T value) {
            this.value = value;
        }

        public T getValue() {
            return value;
        }
    }
}
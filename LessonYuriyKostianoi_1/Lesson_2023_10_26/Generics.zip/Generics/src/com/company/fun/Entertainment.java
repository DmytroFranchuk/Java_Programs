package com.company.fun;

public interface Entertainment {
}

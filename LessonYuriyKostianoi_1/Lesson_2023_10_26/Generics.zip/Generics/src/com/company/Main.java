package com.company;
/*1.1 Настройка иерархии классов: транспорт -> судно -> пассажирский лайнер/прогулочная яхта/военный корабль.
 Пассажирский лайнер и прогулочная яхта должны имплементировать интерфейс Entertainment, предполагаемый метод развлечения.
  1.2 Создайте класса-обёртки для хранения транспорта.
  1.3 Создайте метода паруса, который будет работать только с судами.
  1.4 Создайте метод useTransport, который будет работать только с военными кораблями и их предком.
  1.5 Создайте метод getVoyage, который будет работать только с пассажирскими лайнерами и яхтами.
 * */

import com.company.fun.Entertainment;
import com.company.transport.*;

public class Main {

    private static class TransportWrapper<T extends Transport>{
        private final T value;

        public TransportWrapper(T value){
            this.value = value;
        }
        public T getValue(){
            return value;
        }

        public static <T extends Ship> void sale (T ship){
            if (ship != null) {
                System.out.println(ship);
            }
        }

        public static void useTransport (TransportWrapper <? super WarShip> warShip) {
            System.out.println(warShip.value);
        }
        public static <T extends Ship & Entertainment> void getVoyage (T ship) {
            System.out.println(ship);
        }
    }


  public static void main(String[] args) {
	TransportWrapper<Transport> ship1 = new TransportWrapper<>(new PassengirShip());
	TransportWrapper<Ship> ship2 = new TransportWrapper<>(new Ship());
	TransportWrapper<Plane> plane = new TransportWrapper<>(new Plane());
    TransportWrapper.sale(new WarShip());
    TransportWrapper.useTransport(new TransportWrapper<WarShip>(new WarShip()));
    TransportWrapper.getVoyage(new PassengirYiacht());
//    TransportWrapper.getVoyage(new Ship());
  }
}

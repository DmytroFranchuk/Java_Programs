package com.company.transport;

public class Ship extends Transport{
}

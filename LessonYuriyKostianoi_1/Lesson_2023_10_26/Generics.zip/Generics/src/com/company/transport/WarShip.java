package com.company.transport;

public class WarShip extends Ship{
}

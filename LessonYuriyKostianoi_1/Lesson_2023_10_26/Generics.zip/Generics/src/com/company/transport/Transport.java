package com.company.transport;

public abstract class Transport {
}

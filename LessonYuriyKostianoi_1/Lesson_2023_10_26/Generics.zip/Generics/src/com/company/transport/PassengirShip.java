package com.company.transport;

import com.company.fun.Entertainment;

public class PassengirShip extends Ship implements Entertainment {
}

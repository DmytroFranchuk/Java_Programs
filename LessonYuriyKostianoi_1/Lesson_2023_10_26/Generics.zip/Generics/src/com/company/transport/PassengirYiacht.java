package com.company.transport;

import com.company.fun.Entertainment;

public class PassengirYiacht extends Ship implements Entertainment {
}

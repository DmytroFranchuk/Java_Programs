package com.company.transport;

public class Plane extends Transport{
}

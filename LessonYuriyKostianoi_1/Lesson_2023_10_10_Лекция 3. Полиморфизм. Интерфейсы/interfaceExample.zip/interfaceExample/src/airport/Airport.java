package airport;

import flytransport.FlyingTransport;

public class Airport {
    public void accept(FlyingTransport vehicle) {
        // some code to accept transport
    }
}

package flytransport;

import java.util.List;

public class DomesticatedGryphon implements FlyingTransport{
    @Override
    public void fly(String origin, String destination, List<String> passengers) {
        // DomesticatedGryphon implementation
        System.out.println("Flying with magic");
    }
}

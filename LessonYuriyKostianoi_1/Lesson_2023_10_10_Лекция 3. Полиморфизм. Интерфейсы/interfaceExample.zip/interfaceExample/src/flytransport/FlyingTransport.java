package flytransport;

import java.util.List;

public interface FlyingTransport {
    void fly(String origin, String destination, List<String> passengers);
}

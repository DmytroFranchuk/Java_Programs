package flytransport;

import java.util.List;

public class Helicopter implements FlyingTransport{
    @Override
    public void fly(String origin, String destination, List<String> passengers) {
        // helicopter implementation
        System.out.println("Flying vertically");
    }
}

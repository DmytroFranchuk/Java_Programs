package flytransport;

import java.util.List;

public class Airplane implements FlyingTransport{
    @Override
    public void fly(String origin, String destination, List<String> passengers) {
        // airplane implementation
        System.out.println("Flying horizontally");
    }
}

import airport.Airport;
import flytransport.Airplane;
import flytransport.DomesticatedGryphon;
import flytransport.FlyingTransport;
import flytransport.Helicopter;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        FlyingTransport airplane = new Airplane(); // объект можно сразу присвоить переменной типа интерфейса
        Helicopter helicopter = new Helicopter();
        List<FlyingTransport> transport = List.of(airplane, helicopter, new DomesticatedGryphon()); /* все виды транспорта относятся к разным иерархиям,
        но могут быть приведены к одному типу и быть помещены в одну коллекцию*/
        Airport airport = new Airport();
        // аэропорт может обработать любой тип транспорта, который следует интерфейсу FlyingTransport
        for (FlyingTransport t: transport) {
            airport.accept(t); // каждого вид транспорта может быть принят аэропортом
            t.fly("Tomsk", "Antalya", new ArrayList<>()); // у каждого вида транспорта будет вызвана своя реализация
        }
    }
}
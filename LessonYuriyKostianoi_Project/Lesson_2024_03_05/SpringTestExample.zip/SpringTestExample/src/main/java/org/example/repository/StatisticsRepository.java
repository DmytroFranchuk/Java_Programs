package org.example.repository;

import org.example.entity.statistics.ClientAppStatistic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StatisticsRepository extends JpaRepository<ClientAppStatistic, Long> {
    Optional<ClientAppStatistic> findByClientAppName(String clientAppName);
}

package org.example.entity.user.registration;

public enum ConfirmationMethod {
    EMAIL,
    PHONE,
    GOOGLE_ACCOUNT,
    FACEBOOK_ACCOUNT
}

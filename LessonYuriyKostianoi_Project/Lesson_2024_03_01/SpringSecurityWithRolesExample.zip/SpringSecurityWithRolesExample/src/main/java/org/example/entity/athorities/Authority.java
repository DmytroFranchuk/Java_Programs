package org.example.entity.athorities;

public enum Authority {
    ROLE_READ,
    ROLE_WRITE
}

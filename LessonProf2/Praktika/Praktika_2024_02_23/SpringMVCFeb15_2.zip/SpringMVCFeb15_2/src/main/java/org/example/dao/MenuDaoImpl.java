package org.example.dao;

import org.example.entity.dish.Dish;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.*;
@Component
public class MenuDaoImpl implements MenuDao {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/MenuApp"; // TODO вынести в файл настроек
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "1";
    private static final String DRIVER_CLASS_NAME = "org.postgresql.Driver";
    private static final Connection CONNECTION;

    static {
        try {
            Class.forName(DRIVER_CLASS_NAME); // Требовалось в старых версиях Spring
            CONNECTION = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Cannot load " + DRIVER_CLASS_NAME, e);
        } catch (SQLException e) {
            throw new RuntimeException("Cannot create connection to " + DB_URL, e);
        }
    }
    @Override
    public Dish create(Dish candidate) {
        Objects.requireNonNull(candidate, "Candidate cant be null");
        try {
            Statement statement=CONNECTION.createStatement();
            statement.executeUpdate(
                    "INSERT INTO dishes (name, ingredients) values ('" +candidate.getName() + "','" + candidate.getIngredients()+"');");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return readAll().stream().filter(dish -> dish.getName().equals(candidate.getName())).findFirst().orElseThrow();
    }

    @Override
    public Dish read(long id) {
        try {
            Statement statement=CONNECTION.createStatement();
            ResultSet result = statement.executeQuery("SELECT *  FROM dishes WHERE id="+id+";");
            List<Dish> dishes=new ArrayList<>();
            while (result.next()){
                Dish dish=new Dish(
                        result.getLong("id"),
                        result.getString("name"),
                        result.getString("ingredients")
                );
                dishes.add(dish);
            }
            if (dishes.size()>1) throw new IllegalStateException("id more one");
            return dishes.stream().findFirst().orElseThrow();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Dish> readAll() {
        try {
            Statement statement=CONNECTION.createStatement();
            ResultSet result = statement.executeQuery("SELECT *  FROM dishes;");
            List<Dish> dishes=new ArrayList<>();
            while (result.next()){
                Dish dish=new Dish(
                        result.getLong("id"),
                        result.getString("name"),
                        result.getString("ingredients")
                        );
                dishes.add(dish);
            }
            return dishes;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(long id, Dish dish) {
        try {
            Statement statement=CONNECTION.createStatement();
            statement.executeUpdate(
                    "UPDATE dishes SET name='" + dish.getName() +"', ingredients='"+dish.getIngredients()+
                            "' WHERE id=" + id + ";");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(long id) {
        try {
            Statement statement=CONNECTION.createStatement();
            statement.executeUpdate("DELETE FROM dishes WHERE id=" + id + ";");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
